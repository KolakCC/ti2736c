
public class main {

	public static void perceptron() {
		// add code here
	}

	public static void perceptronDigits() {
		// add code here
	}

	public static void nearestNeighbour() {
		// add code here
	}
	
	public static void nearestNeighbourDigits() {
		// add code here
	}

	public static void main(String[] args) {
		//perceptron();
		//perceptronDigits();
		//nearestNeighbour();
		//nearestNeighbourDigits();
	}

}
